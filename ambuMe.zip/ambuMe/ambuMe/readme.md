The project to automate chekcing process in a college or school. 

Aims: 
1. To use ML and algorithims appropriate algorithims to automate the checking of Answer sheets of the studens.
2. Reduce the burden on teachers.
3. Reduce the time taken for checking process.
4. Remove the Partiality that occurs, due to different/bad handwriting. 

