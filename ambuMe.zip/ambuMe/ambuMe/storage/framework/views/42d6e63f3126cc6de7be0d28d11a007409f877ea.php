<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
               
                <div class="card-header">Dashboard</div>
                <div class="card-body">
                <?php if(Auth::user()->type): ?>
                <button type="button" onClick="window.location='Ambs/create';" class="btn btn-primary">Add new Ambulance</button>
                <hr>
                <?php if(session('msg')): ?>
                
                

                <div class="alert alert-success" style="margin-top:10px;">
                    <strong>Success!</strong>  <?php echo e(session('msg')); ?>

                 
                  </div>
                <?php endif; ?>

                <div style="padding:20px 0;">
                    <h4>
                  Ambulances You have added:
                    </h4>  
                </div>
                
                  
                   <table class="table">
                    <thead>
                      <tr>
                        <th scope="col">Sr No.</th>
                        <th scope="col">Name</th>
                        <th scope="col">Created at</th>
                        <th scope="col">Location</th>
                        <th scope="col">Phone</th>
                        <th scope="col">Status</th>
                        <th scope="col"></th>
                      </tr>
                    </thead>
                    <?php  $i=1 ?>    
                    <tbody>
                     <?php $__currentLoopData = $ambsgiven; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ambu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         
                      <tr>
                        <th scope="row"><?php echo $i ?></th>
                       <td><a href="Ambs/<?php echo e($ambu->id); ?>"><?php echo e($ambu->name); ?></a></td>
                       <td><?php echo e($ambu->created_at->format('d/m/y')); ?></td>
                       <td><?php echo e($ambu->des); ?></td>
                       <td><?php echo e($ambu->phone); ?></td>
                       <td><?php echo e($ambu->status); ?></td>
                       <td><a href="papers/<?php echo e($ambu->id); ?>/result">View more</a></td>

                      </tr>
                      <?php $i++ ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  
         
                     
                    </tbody>
                  </table>




                <?php else: ?>

                <div style="padding:20px 0;">
                    <h4>
                  Ambulances Available for booking:
                    </h4>  
                </div>
                
                  
                   <table class="table">
                    <thead>
                      <tr>
                        <th scope="col">Sr No.</th>
                        <th scope="col">Name</th>
                        <th scope="col">Created at</th>
                        <th scope="col">Location</th>
                        <th scope="col">Phone</th>
                        <th scope="col">Status</th>
                        <th scope="col"></th>
                      </tr>
                    </thead>
                    <?php  $i=1 ?>    
                    <tbody>
                     <?php $__currentLoopData = $ambs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ambu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         
                      <tr>
                        <th scope="row"><?php echo $i ?></th>
                       <td><a href="Ambs/<?php echo e($ambu->id); ?>"><?php echo e($ambu->name); ?></a></td>
                       <td><?php echo e($ambu->created_at->format('d/m/y')); ?></td>
                       <td><?php echo e($ambu->des); ?></td>
                       <td><?php echo e($ambu->phone); ?></td>
                       <td><?php echo e($ambu->status); ?></td>
                       <td><a href="Ambs/<?php echo e($ambu->id); ?>">View more</a></td>

                      </tr>
                      <?php $i++ ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  
         
                     
                    </tbody>
                  </table>


                <?php endif; ?>
            </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>