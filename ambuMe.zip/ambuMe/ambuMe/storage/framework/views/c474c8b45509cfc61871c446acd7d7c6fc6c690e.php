<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" >
               
                <div class="card-header" >Ambulance Information</div>
                <div class="card-body">
                  <h4><?php echo e($paper->name); ?></h4> 
                        Ambulance Description: <b><?php echo e($paper->des); ?></b><br>
                      Status:<b> <?php echo e($paper->status); ?></b><br>
                       Phone: <b><?php echo e($paper->phone); ?></b>
              <br>
                <?php if(!Auth::user()->type): ?>
                      Book Ambulance: 

                        <a href="<?php echo e($paper->id); ?>\b\<?php echo e(Auth::user()->id); ?> ">Book this ambulance</a><hr>
                  <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>