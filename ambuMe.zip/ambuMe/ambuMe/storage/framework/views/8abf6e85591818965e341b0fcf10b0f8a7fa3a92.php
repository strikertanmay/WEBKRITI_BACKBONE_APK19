<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" >
               
                <div class="card-header" >Paper Information</div>
                <div class="card-body">
                  <h4><?php echo e($paper->name); ?></h4> 
                        Paper Description: <b><?php echo e($paper->des); ?></b><br>
                        Number of Questions Questions:<b> <?php echo e($paper->numQ); ?></b><br>
                        Total Marks: <b><?php echo e($paper->total); ?></b>
                           
<hr>
<?php if($paper->status==0): ?>
                      <h5><b> Questions: </b></h5>
                      <hr>
                          
                           <form action="" method="POST">
                                <?php echo csrf_field(); ?>
               
                              
                                   
                                            <?php for($i = 1; $i <=$paper->numQ; $i++): ?>
                                      <div class="form-group">
                                        <label for="Name">Question-<b style="font-size:18px;"><?php echo e($i); ?></b></label>
                                        <input type="text" class="form-control" name="name<?php echo e($i); ?>" id="name<?php echo e($i); ?>" placeholder="Enter Question here">
                                       <br>
                                        <div class="form-row">
                                                <div class="form-group col-md-4">
                                                        <label for="type<?php echo e($i); ?>">Question Type</label>
                                                        <select class="form-control" id="type<?php echo e($i); ?>" name="type<?php echo e($i); ?>">
                                                          <option value="1">Defination/Axiom (One word or One line)</option>
                                                          <option value="2">Mathematical Problem</option>
                                                          <option value="3">Unordered List</option>
                                                          <option value="4">List and Explain</option>
                                                          <option value="5">Ordered List</option>
                                                          <option value="6">Paragragh</option>
                                                          <option value="7">List/Paragraph</option>

                                                        </select>
                                               
                                                </div>
                                                <div class="form-group col-md-">
                                                        <label for="typec<?php echo e($i); ?>">Type of Checking</label>
                                                        <select class="form-control" id="typec<?php echo e($i); ?>" name="typec<?php echo e($i); ?>">
                                                          <option value="0">Exact syntactic</option>
                                                          <option value="1">Exact non syntactic</option>
                                                          <option value="2">Lenient Non Exact</option>
                                                          <option value="3">Non Lenient Non Exact</option>
                                                          

                                                        </select>
                                               
                                                </div>
                                               
                                                <div class="form-group col-md-1">
                                                  <label for="mark<?php echo e($i); ?>">Marks</label>
                                                  <input type="number" class="form-control" name="marks<?php echo e($i); ?>"id="marks<?php echo e($i); ?>">
                                                </div>
                                                <div class="form-group col-md-2">
                                                  <label for="numc<?php echo e($i); ?>">Total Points</label>
                                                  <input type="number" class="form-control" name="numc<?php echo e($i); ?>"id="numc<?php echo e($i); ?>">
                                                </div>
                                                <div class="form-group col-md-2">
                                                  <label for="nump<?php echo e($i); ?>">Points to Check</label>
                                                  <input type="number" class="form-control" name="nump<?php echo e($i); ?>"id="nump<?php echo e($i); ?>">
                                                </div>
                                             </div>
                                             <div class="form-group">
                                
                                                    <label for="Answer<?php echo e($i); ?>">Expected Answer</label>
                                                    <textarea  class="form-control" name="answer<?php echo e($i); ?>" id="answer<?php echo e($i); ?>" placeholder="Enter Expected Answer here"></textarea>
                                                   <br>
                                                    <div class="form-row">
                                                            <div class="form-group col-md-6">
                                                             
                                                                    <label for="Exact<?php echo e($i); ?>">Exact Words Needed</label>
                                                              <input type="text" class="form-control" name="exact<?php echo e($i); ?>"id="exact<?php echo e($i); ?>">
                                                           
                                                            </div>
                                                           
                                                            <div class="form-group col-md-4">
                                                              <label for="Exactmarks<?php echo e($i); ?>">Marks for Exact( ',' Seperated )</label>
                                                              <input type="text" class="form-control" name="emarks<?php echo e($i); ?>"id="emarks<?php echo e($i); ?>">
                                                            </div>
                                                         </div>         
                                                         <div class="form-row">
                                                                <div class="form-group col-md-6">
                                                                 
                                                                        <label for="synsyn<?php echo e($i); ?>">Synonymous Words Needed</label>
                                                                  <input type="text" class="form-control" name="syn<?php echo e($i); ?>"id="syn<?php echo e($i); ?>">
                                                               
                                                                </div>

                                                                <div class="form-group col-md-4">
                                                                  <label for="sMarks<?php echo e($i); ?>">Marks for Synonymous( ',' Seperated )</label>
                                                                  <input type="text" class="form-control" name="smarks<?php echo e($i); ?>"id="smarks<?php echo e($i); ?>">
                                                                </div>
                                                             </div>         
                                                             <div class="form-row">
                                                                    <div class="form-group col-md-6">
                                                                     
                                                                            <label for="Res<?php echo e($i); ?>">Restricted Words </label>
                                                                      <input type="text" class="form-control" name="Res<?php echo e($i); ?>"id="Res<?php echo e($i); ?>">   

                                                                    </div>

                                                                    <div class="form-group col-md-4">
                                                                      <label for="Rmarks<?php echo e($i); ?>">Marks to deduct ( ',' Seperated )</label>
                                                                      <input type="text" class="form-control" name="rmarks<?php echo e($i); ?>"id="rmarks<?php echo e($i); ?>">
                                                                    </div>
                                                                 </div>          
                                             </div>


                                              
                                    <hr>
                                     <?php endfor; ?>
                                    <button type="submit" class="btn btn-primary" >Add Questions</button>
                                 </form>
                           


                      

                            </div>
                        </div>
                
                
                
                </div>
<?php else: ?>
<div style="padding:10px;">
You have added the Questions. 
View/Edit them here: <a href="<?php echo e($paper->id); ?>/edit/"> Questions</a>
              </div>
              <form method="post" action="<?php echo e($paper->id); ?>/check" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                       <input class="form-control"type="text" name="roll" Placeholder="Enter Roll number">

                      </div>
                      <div class="input-group control-group increment" >
                        <input type="file" name="filename[]" class="form-control">
                        <div class="input-group-btn"> 
                          <button class="btn btn-success" type="button"><i class="glyphicon glyphicon-plus"></i>Add</button>
                        </div>
                      </div>
                      <div class="clone hide">
                        <div class="control-group input-group" style="margin-top:10px" >
                          <input type="file" name="filename[]" class="form-control">
                          <div class="input-group-btn"> 
                            <button class="btn btn-danger" type="button"><i class="glyphicon glyphicon-remove"></i> Remove</button>
                          </div>
                        </div>
                      </div>
              
                      <button type="submit" class="btn btn-primary" style="margin-top:10px">Check</button>
              
                </form>        
                </div>
                <?php if(session('msg')): ?>
                
                

                <div class="alert alert-success" style="margin-top:10px;">
                    <strong>Success!</strong>  <?php echo e(session('msg')); ?>

                 
                  </div>
                <?php endif; ?>
              
              <script type="text/javascript">
              
              
                  $(document).ready(function() {
              
                    $(".btn-success").click(function(){ 
                        var html = $(".clone").html();
                        $(".increment").after(html);
                    });
              
                    $("body").on("click",".btn-danger",function(){ 
                        $(this).parents(".control-group").remove();
                    });
              
                  });
              
              </script>
                              

<?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>