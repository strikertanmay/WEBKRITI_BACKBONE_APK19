<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" >
               
                <div class="card-header" >Paper Information</div>
                <div class="card-body">
                  <h4><?php echo e($paper->name); ?></h4> 
                        Paper Description: <b><?php echo e($paper->des); ?></b><br>
                        Number of Questions Questions:<b> <?php echo e($paper->numQ); ?></b><br>
                        Total Marks: <b><?php echo e($paper->total); ?></b>
                           
<hr>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>