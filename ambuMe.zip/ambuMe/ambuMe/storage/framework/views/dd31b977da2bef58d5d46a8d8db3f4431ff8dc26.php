<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
               
                <div class="card-header">Dashboard</div>
                <div class="card-body">
                <?php if(Auth::user()->type): ?>
                <button type="button" onClick="window.location='papers/create';" class="btn btn-primary">Add new Paper</button>
                <hr>
                <?php if(session('msg')): ?>
                
                

                <div class="alert alert-success" style="margin-top:10px;">
                    <strong>Success!</strong>  <?php echo e(session('msg')); ?>

                 
                  </div>
                <?php endif; ?>

                <div style="padding:20px 0;">
                    <h4>
                  Your Papers:
                    </h4>  
                </div>
                
                  
                   <table class="table">
                    <thead>
                      <tr>
                        <th scope="col">Sr No.</th>
                        <th scope="col">Name</th>
                        <th scope="col">Created at</th>
                        <th scope="col">Number of Questions</th>
                        <th scope="col">Total Marks</th>
                        <th scope="col">Status</th>
                        <th scope="col"></th>
                      </tr>
                    </thead>
                    <?php  $i=1 ?>    
                    <tbody>
                     <?php $__currentLoopData = $papersgiven; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         
                      <tr>
                        <th scope="row"><?php echo $i ?></th>
                       <td><a href="papers/<?php echo e($paper->id); ?>"><?php echo e($paper->name); ?></a></td>
                       <td><?php echo e($paper->created_at->format('d/m/y')); ?></td>
                       <td><?php echo e($paper->numQ); ?></td>
                       <td><?php echo e($paper->total); ?></td>
                       <td><?php echo e($paper->status); ?></td>
                       <td><a href="papers/<?php echo e($paper->id); ?>/result">View Result</a></td>

                      </tr>
                      <?php $i++ ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  
         
                     
                    </tbody>
                  </table>




                <?php else: ?>



                <?php endif; ?>
            </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>