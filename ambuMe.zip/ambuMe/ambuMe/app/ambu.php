<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ambu extends Model
{
    //
}
